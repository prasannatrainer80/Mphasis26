package com.java.jdbc.model;

public enum Gender {
	MALE, FEMALE
}
